<h2 align="centre"> ᴢᴀɪᴅ ᴠᴄ ᴘʟᴀʏᴇʀ🔥</h2>

### ᴢᴀɪᴅ ᴠᴄ ᴘʟᴀᴇʀ ɪꜱ ᴀ ᴛᴇʟᴇɢʀᴀᴍ ᴘʀᴏᴊᴇᴄᴛ ʙᴀꜱᴇᴅ ᴏɴ ᴘʏʀᴏɢʀᴀᴍ ꜰᴏʀ ᴘʟᴀʏ ᴍᴜꜱɪᴄꜱ ɪɴ ᴠᴄ ᴄʜᴀᴛꜱ...

<p align="center"><a href="https://t.me/Zaid_Team1"><img src="https://telegra.ph/file/a5efad6976ca08e71ef69.png" width="300"></a></p>
<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>

<h3>ʀᴇQᴜɪʀᴇᴍᴇɴᴛꜱ 📝</h3>

- FFmpeg
- NodeJS [nodesource.com](https://nodesource.com/)
- Python 3.8+ or 3.7
- [PyTgCalls](https://github.com/pytgcalls/pytgcalls)
- [MongoDB](https://cloud.mongodb.com/)

🧪 ɢᴇᴛ STRING_SESSION ꜰʀᴏᴍ ʜᴇʀᴇ:

[![ɢᴇɴᴇʀᴀᴛᴇ ꜱᴇꜱꜱɪᴏɴ](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@BoooCreative/StringSession-1#main.py)
## Repo Stats
![github card](https://github-readme-stats.vercel.app/api/pin/?username=Itsunknown-12&repo=Zaid-Vc-Player&theme=dark)
## ᴄᴏᴍᴍᴀɴᴅꜱ 

- /ᴘʟᴀʏ <ꜱᴏɴɢ ɴᴀᴍᴇ> - ᴘʟᴀʏ ꜱᴏɴɢ ʏᴏᴜ ʀᴇQᴜᴇꜱᴛᴇᴅ
- /ᴘʟᴀʏʟɪꜱᴛ - ꜱʜᴏᴡ ɴᴏᴡ ᴘʟᴀʏɪɴɢ ʟɪꜱᴛ
- /ꜱᴏɴɢ <ꜱᴏɴɢ ɴᴀᴍᴇ> - ᴅᴏᴡɴʟᴏᴀᴅ ꜱᴏɴɢꜱ ʏᴏᴜ ᴡᴀɴᴛ Qᴜɪᴄᴋʟʏ
- /ꜱᴇᴀʀᴄʜ <Qᴜᴇʀʏ> - ꜱᴇᴀʀᴄʜ ᴠɪᴅᴇᴏꜱ ᴏɴ ʏᴏᴜᴛᴜʙᴇ ᴡɪᴛʜ ᴅᴇᴛᴀɪʟꜱ
- /ᴠꜱᴏɴɢ <ꜱᴏɴɢ ɴᴀᴍᴇ> - ᴅᴏᴡɴʟᴏᴀᴅ ᴠɪᴅᴇᴏꜱ ʏᴏᴜ ᴡᴀɴᴛ Qᴜɪᴄᴋʟʏ
- /ʟʏʀɪᴄ <ꜱᴏɴɢ ɴᴀᴍᴇ> - ʟʏʀɪᴄꜱ ꜱᴄʀᴀᴘᴘᴇʀ
- /ᴠᴋ <ꜱᴏɴɢ ɴᴀᴍᴇ> - ɢᴇɴᴇʀᴀᴛᴇ ꜱᴏɴɢ ᴡɪᴛʜᴏᴜᴛ ᴅᴏᴡɴʟᴏᴀᴅ

#### ᴀᴅᴍɪɴꜱ ᴏɴʟʏ 👷‍♂️
- /ᴘʟᴀʏᴇʀ - ᴏᴘᴇɴ ᴍᴜꜱɪᴄ ᴘʟᴀʏᴇʀ ꜱᴇᴛᴛɪɴɢꜱ ᴘᴀɴᴇʟ
- /ᴘᴀᴜꜱᴇ - ᴘᴀᴜꜱᴇ ꜱᴏɴɢ ᴘʟᴀʏ
- /ʀᴇꜱᴜᴍᴇ - ʀᴇꜱᴜᴍᴇ ꜱᴏɴɢ ᴘʟᴀʏ
- /ꜱᴋɪᴘ - ᴘʟᴀʏ ɴᴇxᴛ ꜱᴏɴɢ
- /ᴇɴᴅ - ꜱᴛᴏᴘ ᴍᴜꜱɪᴄ ᴘʟᴀʏ
- /ᴍᴜꜱɪᴄᴘʟᴀʏᴇʀ ᴏɴ - ᴛᴏ ᴅɪꜱᴀʙʟᴇ ᴍᴜꜱɪᴄ ᴘʟᴀʏᴇʀ ɪɴ ʏᴏᴜʀ ɢʀᴏᴜᴘ
- /ᴍᴜꜱɪᴄᴘʟᴀʏᴇʀ ᴏꜰꜰ - ᴛᴏ ᴇɴᴀʙʟᴇ ᴍᴜꜱɪᴄ ᴘʟᴀʏᴇʀ ɪɴ ʏᴏᴜʀ ɢʀᴏᴜᴘ
- /ᴜꜱᴇʀʙᴏᴛᴊᴏɪɴ - ɪɴᴠɪᴛᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴛᴏ ʏᴏᴜʀ ᴄʜᴀᴛ
- /ᴜꜱᴇʀʙᴏᴛʟᴇᴀᴠᴇ - ʀᴇᴍᴏᴠᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ꜰʀᴏᴍ ʏᴏᴜʀ ᴄʜᴀᴛ
- /ʀᴇʟᴏᴀᴅ - ʀᴇꜰʀᴇꜱʜ ᴀᴅᴍɪɴ ʟɪꜱᴛ
- /ᴜᴘᴛɪᴍᴇ - ᴄʜᴇᴄᴋ ᴛʜᴇ ʙᴏᴛ ᴜᴘᴛɪᴍᴇ ꜱᴛᴀᴛᴜꜱ
- /ᴘɪɴɢ - ᴄʜᴇᴄᴋ ᴛʜᴇ ʙᴏᴛ ᴘɪɴɢ ꜱᴛᴀᴛᴜꜱ
- /ᴀᴜᴛʜ - ᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴘᴇᴏᴘʟᴇ ᴛᴏ ᴀᴄᴄᴇꜱꜱ ᴛʜᴇ ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅꜱ
- /ᴅᴇᴀᴜᴛʜ - ᴅᴇᴀᴜᴛʜᴏʀɪᴢᴇᴅ ᴘᴇᴏᴘʟᴇ ᴛᴏ ᴀᴄᴄᴇꜱꜱ ᴛʜᴇ ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅꜱ
- /ᴄᴏɴᴛʀᴏʟ - ᴏᴘᴇɴ ᴛʜᴇ ᴍᴜꜱɪᴄ ᴘʟᴀʏᴇʀ ᴄᴏɴᴛʀᴏʟ ᴘᴀɴᴇʟ

### ꜱᴜᴅᴏ ᴜꜱᴇʀ 🧙‍♂️
- /ꜱᴛᴀᴛꜱ - ꜱᴇᴇ ᴛʜᴇ ʙᴏᴛ ꜱᴛᴀᴛɪꜱᴛɪᴄ
- /ᴘᴍᴘᴇʀᴍɪᴛ ᴏɴ | ᴏꜰꜰ ᴛᴜʀɴ ᴏɴ/ᴏꜰꜰ ᴛʜᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴘᴍᴘᴇʀᴍɪᴛ
- /ᴜꜱᴇʀʙᴏᴛʟᴇᴀᴠᴇᴀʟʟ - ᴏʀᴅᴇʀ ᴛʜᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ ᴛᴏ ʟᴇᴀᴠᴇ ᴀʟʟ ɢʀᴏᴜᴘꜱ
- /ɢᴄᴀꜱᴛ - ꜱᴇɴᴅ ᴀ ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴍᴇꜱꜱᴀɢᴇ ꜰʀᴏᴍ ᴛʜᴇ ᴀꜱꜱɪꜱᴛᴀɴᴛ

### ᴏᴡɴᴇʀ ᴏɴʟʏ 👨🏻‍✈️
- /ʙʀᴏᴀᴅᴄᴀꜱᴛ - ꜱᴇɴᴅ ᴀ ʙʀᴏᴀᴅᴄᴀꜱᴛ ᴍᴇꜱꜱᴀɢᴇ ꜰʀᴏᴍ ᴛʜᴇ ʙᴏᴛ
- /ʙʟᴏᴄᴋ - ʙʟᴏᴄᴋ ᴘᴇᴏᴘʟᴇ ꜰᴏʀ ᴜꜱɪɴɢ ʏᴏᴜʀ ʙᴏᴛ
- /ᴜɴʙʟᴏᴄᴋ - ᴜɴʙʟᴏᴄᴋ ᴘᴇᴏᴘʟᴇ ʏᴏᴜ ʙʟᴏᴄᴋᴇᴅ ꜰᴏʀ ᴜꜱɪɴɢ ʏᴏᴜʀ ʙᴏᴛ
- /ʙʟᴏᴄᴋʟɪꜱᴛ - ꜱʜᴏᴡ ᴛʜᴇ ʟɪꜱᴛ ᴏꜰ ᴀʟʟ ᴘᴇᴏᴘʟᴇ ᴡʜᴏ'ꜱ ʙʟᴏᴄᴋᴇᴅ ꜰᴏʀ ᴜꜱɪɴɢ ʏᴏᴜʀ ʙᴏᴛ

### ᴘᴍ-ᴘᴇʀᴍɪᴛ 💬
- .ʏᴇꜱ - ᴀᴘᴘʀᴏᴠᴇ ᴜꜱᴇʀ ꜰᴏʀ ꜱᴇɴᴅɪɴɢ ᴍᴇꜱꜱᴀɢᴇ ᴛᴏ ᴀꜱꜱɪꜱᴛᴀɴᴛ
- .ɴᴏ - ᴅɪꜱᴀᴘᴘʀᴏᴠᴇ ᴜꜱᴇʀ ꜰᴏʀ ꜱᴇɴᴅɪɴɢ ᴍᴇꜱꜱᴀɢᴇ ᴛᴏ ᴀꜱꜱɪꜱᴛᴀɴᴛ

## 🔎 ꜱᴜᴘᴘᴏʀᴛ ɪɴʟɪɴᴇ ꜱᴇᴀʀᴄʜ

## ʜᴇʀᴏᴋᴜ ᴅᴇᴘʟᴏʏᴍᴇɴᴛꜱ 💜
ʜᴇʀᴏᴋᴜ ɪꜱ ᴛʜᴇ ᴇᴀꜱʏ ᴡᴀʏ ᴛᴏ ʜᴏꜱᴛ ᴜʀ ᴀᴘᴘꜱ

[![ᴢᴠᴄ ᴅᴇᴘʟᴏʏ](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Itsunknown-12/Zaid-Vc-Player)

## ᴅᴇᴘʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ 🚄
ꜰᴏʀ ᴅᴇᴘʟᴏʏ ᴏɴ ʀᴀɪʟᴡᴀʏ ᴍᴀᴋᴇ [Necessary Variables Here](https://github.com/Itsunknown-12/Zaid-Vc-Player/blob/main/example.env), ᴜ ʜᴀᴠᴇ ᴛᴏ ꜰɪʟʟ.

[![Deploy+on+Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/Itsunknown-12/Zaid-Vc-Player&envs=SESSION_NAME,BOT_TOKEN,BOT_USERNAME,BOT_NAME,GROUP_SUPPORT,ASSISTANT_NAME,OWNER_NAME,OWNER_ID,DATABASE_URL,LOG_CHANNEL,BROADCAST_AS_COPY,UPDATES_CHANNEL,API_ID,API_HASH,PMPERMIT,SUDO_USERS,DURATION_LIMIT)

### ꜱᴘᴇᴄɪᴀʟ ᴄʀᴇᴀᴅɪᴛꜱ 💖
- [Levina](https://github.com/levina-lab): ʀᴇᴀʟ ᴅᴇᴠ💞



### ꜱᴜᴘᴘᴏʀᴛ ᴀɴᴅ ᴜᴘᴅᴀᴛᴇꜱ🎑
<a href="https://t.me/Zaid_Updates"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/Zaid_Updates"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
